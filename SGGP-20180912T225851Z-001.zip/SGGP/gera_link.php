<?php

error_reporting(0);
ini_set(“display_errors”, 0 );

?>

<?php
date_default_timezone_set('America/Sao_Paulo');
$date = date('Y-m-d H:i');
include("admin/html/pag/conexao.php");

    $prontuario = $_POST['prontuarioLoginLider'];

$query = sprintf("SELECT nome, email, senha FROM lideres WHERE prontuario ='$prontuario'");
// executa a query
$dados = mysql_query($query, $con) or die(mysql_error());
// transforma os dados em um array
$linha = mysql_fetch_assoc($dados);
// calcula quantos dados retornaram
$total = mysql_num_rows($dados);

// se o número de resultados for maior que zero, mostra os dados
if($linha["nome"] != NULL) {
    header('Location: email.php/?email='.$linha["email"].'&nome='.$linha["nome"].'&senha='.$linha["senha"].'&data='.$date.'&prontuario='.$prontuario);
}
else{
     header('Location: login/esqueceu_senha.php');
}

// tira o resultado da busca da memória
mysql_free_result($dados);
?>