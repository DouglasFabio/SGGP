<!DOCTYPE html>
<html dir="ltr" lang="en">

<?php
    // A sessão precisa ser iniciada em cada página diferente
  if (!isset($_SESSION)) session_start();
    
    
  // Verifica se não há a variável da sessão que identifica o usuário
  if (!isset($_SESSION['Usuario'])) {
      // Redireciona o visitante de volta pro login
      header("Location: index_lider.php"); exit;
  }
    
    
include("head.php");
?>

<body>
    <!-- ============================================================== -->
    <!-- Preloader - style you can find in spinners.css -->
    <!-- ============================================================== -->
    <div class="preloader">
        <div class="lds-ripple">
            <div class="lds-pos"></div>
            <div class="lds-pos"></div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- Main wrapper - style you can find in pages.scss -->
    <!-- ============================================================== -->
    <div id="main-wrapper" data-navbarbg="skin6" data-theme="light" data-layout="vertical" data-sidebartype="full" data-boxed-layout="full">
        <!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
        <header class="topbar" data-navbarbg="skin6">
            <nav class="navbar top-navbar navbar-expand-md navbar-light">
                <?php
                    include("logotipo.php");
                ?>
                 <!-- ============================================================== -->
                <!-- MENU SUPERIOR -->
                <!-- ============================================================== -->
                <?php
                    include("menu_superior.php");
                ?>
            </nav>
        </header>
        <!-- ============================================================== -->
        <!-- End Topbar header -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <aside class="left-sidebar" data-sidebarbg="skin5">
             <?php
                include("menu_lateral.php");
            ?>
        </aside>
        <!-- ============================================================== -->
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <!-- ============================================================== -->
        <div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-5 align-self-center">
                        <h4 class="page-title">Controle de permissões</h4>
                    </div>
                    <div class="col-7 align-self-center">
                        <div class="d-flex align-items-center justify-content-end">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item">
                                        <a href="#">SGGP</a>
                                    </li>
                                    
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Controle de permissões</h4>
                                <h6 class="card-title m-t-40"><i class="m-r-5 font-18 mdi mdi-numeric-1-box-multiple-outline"></i>Gerenciamento de ADMINISTRADORES:</h6>
                                    <?php
                                 
                                        include("conexao2.php");
                                        if (mysqli_connect_errno()) {
                                            printf("Connect failed: %s\n", mysqli_connect_error());
                                            exit();
                                        }
                                    ?>
                                
                                
                                
                                <div class="table-responsive">
                                    <table class="table table-hover">
                                        <thead>
                                            <tr>
                                                <th scope="col">Usuário</th>
                                                <th scope="col">Tipo</th>
                                                <th scope="col">Atribuição</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                               <?php
                                                $busca = "SELECT login FROM administradores";
                                                
                                                if ($stmt = $mysqli->prepare($busca)) {

                                                    /* execute statement */
                                                    $stmt->execute();

                                                    /* bind result variables */
                                                    $stmt->bind_result($login);

                                                    while ($stmt->fetch()) {
                                                        printf('<tr><td>'.$login.'</td>
                                                                    <td><span class="label label-rounded label-primary">ADMIN</span></td>
                                                                    <td><a href="editar_permissoes.php" class="login50-form-btn label label-info label-rounded">Editar</a></td>
                                                                </tr>');
                                                    }
                                                        
                                                }else
                                                {
                                                    printf( "Erro no SQL!");
                                                }

                                                  $stmt->close();
                                                ?>
                                        </tbody>
                                        <tbody>
                                               <?php
                                                $busca2 = "SELECT nome FROM lideres";
                                                
                                                if ($stmt = $mysqli->prepare($busca2)) {

                                                    /* execute statement */
                                                    $stmt->execute();

                                                    /* bind result variables */
                                                    $stmt->bind_result($nome);

                                                    while ($stmt->fetch()) {
                                                        printf('<tr><td>'.$nome.'</td>
                                                                    <td><span class="label label-success label-rounded">LÍDER</span></td>
                                                                    <td><a href="editar_permissoes.php" class="login50-form-btn label label-info label-rounded">Editar</a></td>
                                                                </tr>');
                                                    }
                                                        
                                                }else
                                                {
                                                    printf( "Erro no SQL!");
                                                }

                                                  $stmt->close();
                                                ?>
                                        </tbody>
                                    </table>
                            </div>
              
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Right sidebar -->
                <!-- ============================================================== -->
                <!-- .right-sidebar -->
                <!-- ============================================================== -->
                <!-- End Right sidebar -->
                <!-- ============================================================== -->
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- footer -->
            <!-- ============================================================== -->
            
        </div>
            <footer class="footer text-center">
                Todos os direitos reservados por SGGP. Desenvolvido por
                <a href="https://wrappixel.com">SGGP</a>.
            </footer>
    </div>
    </div>
    <script src="../../assets/libs/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="../../assets/libs/popper.js/dist/umd/popper.min.js"></script>
    <script src="../../assets/libs/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- slimscrollbar scrollbar JavaScript -->
    <script src="../../assets/extra-libs/sparkline/sparkline.js"></script>
    <!--Wave Effects -->
    <script src="../../dist/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="../../dist/js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
    <script src="../../dist/js/custom.min.js"></script>
  
</body>

</html>