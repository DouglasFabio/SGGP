<!DOCTYPE html>
<html lang="en">
<?php
      // A sessão precisa ser iniciada em cada página diferente
  if (!isset($_SESSION)) session_start();
  // Verifica se não há a variável da sessão que identifica o usuário
  if (!isset($_SESSION['UsuarioProntuario'])) {
      // Destrói a sessão por segurança
      session_destroy();
      // Redireciona o visitante de volta pro login
      header("Location: login_lider.php"); exit;
  }

    include("head_login.php");
?>
<body>


	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100 p-t-50 p-b-90">
				<form name="formADM" method="post" action="verificaDados.php"class="login100-form validate-form flex-sb flex-w">
					<span class="login100-form-title p-b-51">
						Bem-vindo ao SGGP<br><br>
					     <center><h6>Altere sua senha</h6></center>
                 <?php
	               if(isset($_GET['erro'])){
                 ?>
                 <script>
	               window.alert("Senhas não conferem!");
                 </script>
                 <?php 
                   } 
                 ?>
                </span>
					<div class="wrap-input100 validate-input m-b-16" data-validate = "Senha é obrigatória">
						<input class="input100" type="password" name="senha" id="senhaADM" placeholder="Senha" required>
						<span class="focus-input100"></span>
					</div>
					
					<div class="wrap-input100 validate-input m-b-16" data-validate = "Senha é obrigatória">
						<input class="input100" type="password" name="confsenha" id="confsenhaADM" placeholder="Repita a senha" required>
						<span class="focus-input100"></span>
                    </div>

					<div class="container-login100-form-btn m-t-17">
						<button class="login100-form-btn">
						Salvar
                        </button>
					</div>

				</form>
			</div>
		</div>
	</div>
	

	<div id="dropDownSelect1"></div>
<?php
    include("scripts_login.php");
?>

</body>
</html>