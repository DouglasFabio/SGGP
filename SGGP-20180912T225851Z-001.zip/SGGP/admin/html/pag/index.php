<!DOCTYPE html>
<html dir="pag" lang="en">
  <!-- ============================================================== -->
                <!--  HEAD -->
   <!-- ============================================================== -->
<?php
      // A sessão precisa ser iniciada em cada página diferente
  if (!isset($_SESSION)) session_start();
    
    
  // Verifica se não há a variável da sessão que identifica o usuário
  if (!isset($_SESSION['Usuario'])) {
      // Destrói a sessão por segurança
      session_destroy();
      // Redireciona o visitante de volta pro login
      
      
      
      header("Location: index_lider.php"); exit;
  }
    
    
include("head.php");
?>
<body>
    <div class="preloader">
        <div class="lds-ripple">
            <div class="lds-pos"></div>
            <div class="lds-pos"></div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- Main wrapper - style you can find in pages.scss -->
    <!-- ============================================================== -->
    <div id="main-wrapper" data-navbarbg="skin6" data-theme="light" data-layout="vertical" data-sidebartype="full" data-boxed-layout="full">
        <!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
        <header class="topbar" data-navbarbg="skin6">
            <nav class="navbar top-navbar navbar-expand-md navbar-light">
                <?php
                    include("logotipo.php");
                ?>
                 <!-- ============================================================== -->
                <!-- MENU SUPERIOR -->
                <!-- ============================================================== -->
                <?php
                    include("menu_superior.php");
                ?>
            </nav>
        </header>
        <aside class="left-sidebar" data-sidebarbg="skin5">
            <!-- ============================================================== -->
            <!-- MENU LATERAL -->
            <!-- ============================================================== -->
            <?php
                include("menu_lateral.php");
                include("conexao2.php");
            ?>
        </aside>
        <div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-5 align-self-center">
                        <h4 class="page-title">Início</h4>
                    </div>
                    <div class="col-7 align-self-center">
                        <div class="d-flex align-items-center justify-content-end">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item">
                                        <a href="#">SGGP</a>
                                    </li>
                                    <li class="breadcrumb-item active" aria-current="page">Início</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
                <div class="row">
                    <!-- column -->
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Usuários Cadastrados</h4>
                            </div>
                            <div class="table-responsive">
                               <table class="table table-hover">
                                <thead>
                                            <tr>
                                                <th scope="col">Usuário</th>
                                                <th scope="col">Tipo</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                               <?php
                                                $busca = "SELECT login FROM administradores";
                                                
                                                if ($stmt = $mysqli->prepare($busca)) {

                                                    /* execute statement */
                                                    $stmt->execute();

                                                    /* bind result variables */
                                                    $stmt->bind_result($login);

                                                    while ($stmt->fetch()) {
                                                        printf('<tr><td>'.$login.'</td>
                                                                    <td><span class="label label-rounded label-primary">ADMIN</span></td>
                                                                </tr>');
                                                    }
                                                        
                                                }else
                                                {
                                                    printf( "Erro no SQL!");
                                                }

                                                  $stmt->close();
                                                ?>
                                        </tbody>
                                        <tbody>
                                               <?php
                                                $busca2 = "SELECT nome FROM lideres";
                                                
                                                if ($stmt = $mysqli->prepare($busca2)) {

                                                    /* execute statement */
                                                    $stmt->execute();

                                                    /* bind result variables */
                                                    $stmt->bind_result($nome);

                                                    while ($stmt->fetch()) {
                                                        printf('<tr><td>'.$nome.'</td>
                                                                    <td><span class="label label-success label-rounded">LÍDER</span></td>
                                                                </tr>');
                                                    }
                                                        
                                                }else
                                                {
                                                    printf( "Erro no SQL!");
                                                }

                                                  $stmt->close();
                                                ?>
                                        </tbody>
                                    </table>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <!-- column -->
                    
                    <!-- column -->
                </div>
            </div>
            <footer class="footer text-center">
                Todos os direitos reservados por SGGP. Desenvolvido por:
                <a href="">SGGP</a>.
            </footer>

        </div>
        <?php
            include("scripts.php");
        ?>
</body>
</html>