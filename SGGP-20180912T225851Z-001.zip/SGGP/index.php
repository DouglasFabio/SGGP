<?php

error_reporting(0);
ini_set(“display_errors”, 0 );

?>

<?php
include("/admin/html/pag/conexao.php");

$query = sprintf("SELECT acesso FROM verificaacesso");
// executa a query
$dados = mysql_query($query, $con) or die(mysql_error());
// transforma os dados em um array
$linha = mysql_fetch_assoc($dados);
// calcula quantos dados retornaram
$total = mysql_num_rows($dados);

echo $linha["acesso"];
// se o número de resultados for maior que zero, mostra os dados
if($linha["acesso"] == 0) {

    header('Location: login/index.php');
}
else{
    
     header('Location: pagina_inicial/index.php');
}

// tira o resultado da busca da memória
mysql_free_result($dados);
?>