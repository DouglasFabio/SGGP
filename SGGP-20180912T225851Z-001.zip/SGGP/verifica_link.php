<?php

error_reporting(0);
ini_set(“display_errors”, 0 );

?>

<?php
date_default_timezone_set('America/Sao_Paulo');
$date = date('Y-m-d H:i');
$data = $_GET["data"];
$senha = $_GET["cod"];
$prontuario = $_GET["pro"];

$conn = new mysqli("localhost", "root", "", "bd_sggp");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT `prontuario` ,`nome`, `email` FROM `lideres` WHERE `prontuario` = ".$prontuario." AND `senha` =".$senha;
$result = $conn->query($sql);

if ($result->num_rows > 0) {

      $resultado = $result->fetch_assoc();
      
      // Se a sessão não existir, inicia uma
      if (!isset($_SESSION)) session_start();
    
      // Salva os dados encontrados na sessão
      $_SESSION['UsuarioProntuario'] = $resultado['prontuario'];
      $_SESSION['UsuarioNome'] = $resultado['nome'];
      $_SESSION['UsuarioEmail'] = $resultado['email'];
      // Redireciona o visitante
      
} else {
    echo "Login inválido!"; exit;
}

$conn->close();


if(intval(substr($date, -5, 2))>intval(substr($data, -5, 2))){
    if(intval(substr($data, -2, 2)) < 10){
        session_destroy(); 
        header("Location: index.php");
    }
    else if((intval(substr($date, -2, 2))-intval(substr($data, -2, 2))) < 50){
        session_destroy(); 
        header("Location: index.php");
    }
    else{
        
        header("Location: ../login/troca_senha.php");
    }
}
else if((intval(substr($date, -2, 2))-intval(substr($data, -2, 2))) < 10){
    
    header("Location: ../login/troca_senha.php");
}
else{
    session_destroy(); 
    header("Location: index.php");
}
?>