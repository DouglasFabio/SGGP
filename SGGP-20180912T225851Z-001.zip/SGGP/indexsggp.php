<?php

error_reporting(0);
ini_set(“display_errors”, 0 );

?>

<?php
// definições de host, database, usuário e senha
$host = "localhost";
$db   = "sggp";
$user = "root";
$pass = "toor";
// conecta ao banco de dados
$con = mysql_pconnect($host, $user, $pass) or trigger_error(mysql_error(),E_USER_ERROR); 
// seleciona a base de dados em que vamos trabalhar
mysql_select_db($db, $con);
// cria a instrução SQL que vai selecionar os dados

$query = sprintf("SELECT first, access FROM firstaccess");
// executa a query
$dados = mysql_query($query, $con) or die(mysql_error());
// transforma os dados em um array
$linha = mysql_fetch_assoc($dados);
// calcula quantos dados retornaram
$total = mysql_num_rows($dados);

// se o número de resultados for maior que zero, mostra os dados
if($linha["access"] == 0) {
    $query = sprintf("UPDATE firstaccess SET access = 1 WHERE first = 1");
    $dados = mysql_query($query, $con) or die(mysql_error());
    include('loguin.php');
}
else{
    include('principal.php');
}

// tira o resultado da busca da memória
mysql_free_result($dados);
?>