 
<?php
      // A sessão precisa ser iniciada em cada página diferente
  if (!isset($_SESSION)) session_start();

  // Verifica se não há a variável da sessão que identifica o usuário
  if (!isset($_SESSION['UsuarioProntuario'])) {
      // Destrói a sessão por segurança
      session_destroy();
      // Redireciona o visitante de volta pro login
      header("Location: troca_sernha.php"); exit;
  }

                $senha1 = $_POST['senha'];
                $senha2 = $_POST['confsenha'];
            
$conn = new mysqli("localhost", "root", "", "bd_sggp");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
                if($senha1 == $senha2){
                    $comando_sql = "UPDATE `lideres` SET `senha` = ".$senha1." WHERE `prontuario` = ".$_SESSION['UsuarioProntuario'];

	                $resultado = mysqli_query($conn, $comando_sql);
if($resultado)
    header('Location: ../admin/html/pag/index.php');
else 
    header('Location: index.php?erro=1');
                    
                }else{
                      header('Location: index.php?erro=1');
                }
?>
            
           
 