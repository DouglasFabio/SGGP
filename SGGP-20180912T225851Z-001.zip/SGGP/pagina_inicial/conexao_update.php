<?php
$conexao = new mysqli('localhost', 'root', 'toor', 'bd_sggp');
				
										// Check conexaoection
										if ($conexao->connect_error) {
											die("connection failed: " . $conexao->connect_error);
										} 
?>										