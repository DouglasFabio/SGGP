 
<?php
                $login = $_POST['loginADM'];
                $email = $_POST['emailADM'];
                $senha1 = $_POST['senhaADM'];
                $senha2 = $_POST['confsenhaADM'];
                date_default_timezone_set('America/Sao_Paulo');
                $data = date('Y-m-d H:i:s');
            
                if($senha1 == $senha2){
                    $comando_sql = "INSERT INTO `administradores` (`login`, `email`, `senha`, `data`) 
	                                VALUES ('$login', '$email', '$senha1', '$data');";

	                $mysqli = mysqli_init();

	               if (! $mysqli) {
    	               die('A função mysqli_init falhou');
	               }
	               
                   include("conexao2.php");         
                   //--------------------------------------------------------------------------------------------

                   if ($mysqli->query($comando_sql) === TRUE) {

                        include("conexao.php");

                        $query = sprintf("SELECT acesso FROM verificaacesso");
                        // executa a query
                        $dados = mysql_query($query, $con) or die(mysql_error());
                        // transforma os dados em um array
                        $linha = mysql_fetch_assoc($dados);
                        // calcula quantos dados retornaram
                        $total = mysql_num_rows($dados);

                        // se o número de resultados for maior que zero, mostra os dados
                        if($linha["acesso"] == 0) {
                                $query = sprintf("UPDATE verificaacesso SET acesso = 1 WHERE acesso = 0");
                            $dados = mysql_query($query, $con) or die(mysql_error());
                        }

                        // tira o resultado da busca da memória
                        mysql_free_result($dados);
                       
                        header('Location: ../admin/html/pag');
                       
                   } else {
                        echo "Erro ao tentar salvar: " . $mysqli->error;
                   }

                    $mysqli->close();
                    
                }else{
                      header('Location: index.php?erro=1');
                }
            ?>
            
           
 