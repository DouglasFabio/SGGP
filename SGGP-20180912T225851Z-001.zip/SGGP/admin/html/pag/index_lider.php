<!DOCTYPE html>
<html dir="pag" lang="en">
  <!-- ============================================================== -->
                <!--  HEAD -->
   <!-- ============================================================== -->
<?php
      // A sessão precisa ser iniciada em cada página diferente
  if (!isset($_SESSION)) session_start();
    
    
  // Verifica se não há a variável da sessão que identifica o usuário
  if (!isset($_SESSION['UsuarioProntuario'])) {
      // Destrói a sessão por segurança
      session_destroy();
      // Redireciona o visitante de volta pro login
      header("Location: ../../../login/login_lider.php"); exit;
  }
    
    
include("head.php");
?>
<body>
    <div class="preloader">
        <div class="lds-ripple">
            <div class="lds-pos"></div>
            <div class="lds-pos"></div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- Main wrapper - style you can find in pages.scss -->
    <!-- ============================================================== -->
    <div id="main-wrapper" data-navbarbg="skin6" data-theme="light" data-layout="vertical" data-sidebartype="full" data-boxed-layout="full">
        <!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
        <header class="topbar" data-navbarbg="skin6">
            <nav class="navbar top-navbar navbar-expand-md navbar-light">
                <?php
                    include("logotipo.php");
                ?>
                 <!-- ============================================================== -->
                <!-- MENU SUPERIOR -->
                <!-- ============================================================== -->
                <?php
                    include("menu_superior.php");
                ?>
            </nav>
        </header>
        <aside class="left-sidebar" data-sidebarbg="skin5">
            <!-- ============================================================== -->
            <!-- MENU LATERAL -->
            <!-- ============================================================== -->
                <?php
                    include("menu_lateral.php");
                ?>
        </aside>

        </div>
        <?php
            include("scripts.php");
        ?>
</body>
</html>