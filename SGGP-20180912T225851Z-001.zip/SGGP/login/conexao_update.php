<?php
$conexao = new mysqli('localhost', 'root', '', 'bd_sggp');
				
										// Check conexaoection
										if ($conexao->connect_error) {
											die("connection failed: " . $conexao->connect_error);
										} 
?>										