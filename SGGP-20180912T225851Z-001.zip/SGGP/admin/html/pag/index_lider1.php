<!DOCTYPE html>
<html dir="pag" lang="en">
  <!-- ============================================================== -->
                <!--  HEAD -->
   <!-- ============================================================== -->
<?php
      // A sessão precisa ser iniciada em cada página diferente
  if (!isset($_SESSION)) session_start();
    
    
  // Verifica se não há a variável da sessão que identifica o usuário
  if (!isset($_SESSION['UsuarioProntuario'])) {
      // Destrói a sessão por segurança
      session_destroy();
      // Redireciona o visitante de volta pro login
      header("Location: ../../../login/login_lider.php"); exit;
  }
    
    
include("head.php");
?>
<body>
    <div class="preloader">
        <div class="lds-ripple">
            <div class="lds-pos"></div>
            <div class="lds-pos"></div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- Main wrapper - style you can find in pages.scss -->
    <!-- ============================================================== -->
    <div id="main-wrapper" data-navbarbg="skin6" data-theme="light" data-layout="vertical" data-sidebartype="full" data-boxed-layout="full">
        <!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
        <header class="topbar" data-navbarbg="skin6">
            <nav class="navbar top-navbar navbar-expand-md navbar-light">
                <?php
                    include("logotipo.php");
                ?>
                 <!-- ============================================================== -->
                <!-- MENU SUPERIOR -->
                <!-- ============================================================== -->
                <?php
                    include("menu_superior.php");
                ?>
            </nav>
        </header>

        </div>
        <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-12">
                        <div class="card card-body">
                            <h4 class="card-title">Atualize seu dados</h4>
                            <form class="form-horizontal m-t-30" action="../../../login/verificaDados.php" method="post">
                                <div class="form-group">
                                    <label>Nova Senha</label>
                                    <input type="password" class="form-control" placeholder="Senha" id="senha" name="senha">
                                </div>
                                <div class="form-group">
                                    <label>Repita a Senha</label>
                                    <input type="password" class="form-control" placeholder="Confirmar a Senha" id="confsenha" name="confsenha">
                                </div>
                                <div class="form-group">
                                    <label>Link Lattes</label>
                                    <input type="text" class="form-control" placeholder="Link Lattes">
                                </div>
                                <div class="form-group">
                                    <label>Carregue uma foto</label>
                                    <input type="file" class="form-control">
                                </div>
                                <div class="form-group">
                                    <button type="submit" class="form-control">Confirma</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Right sidebar -->
                <!-- ============================================================== -->
                <!-- .right-sidebar -->
                <!-- ============================================================== -->
                <!-- End Right sidebar -->
                <!-- ============================================================== -->
            </div>
    
        <?php
            include("scripts.php");
        ?>
</body>
</html>