<!DOCTYPE html>
<html dir="pag" lang="en">
  <!-- ============================================================== -->
                <!--  HEAD -->
   <!-- ============================================================== -->
<?php
    // A sessão precisa ser iniciada em cada página diferente
  if (!isset($_SESSION)) session_start();
    
    
  // Verifica se não há a variável da sessão que identifica o usuário
  if (!isset($_SESSION['Usuario'])) {
      // Redireciona o visitante de volta pro login
      header("Location: index_lider.php"); exit;
  }  
    
    
include("head.php");
?>
<style>
        input[type=number]::-webkit-inner-spin-button { 
            -webkit-appearance: none;
            cursor:pointer;
            display:block;
            width:8px;
            color: #333;
            text-align:center;
            position:relative;
        }
       input[type=number] { 
           -moz-appearance: textfield;
           appearance: textfield;
           margin: 0; 
        }
</style>

<body>
    <!-- ============================================================== -->
    <!-- Preloader - style you can find in spinners.css -->
    <!-- ============================================================== -->
    <div class="preloader">
        <div class="lds-ripple">
            <div class="lds-pos"></div>
            <div class="lds-pos"></div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- Main wrapper - style you can find in pages.scss -->
    <!-- ============================================================== -->
    <div id="main-wrapper" data-navbarbg="skin6" data-theme="light" data-layout="vertical" data-sidebartype="full" data-boxed-layout="full">
        <!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
        <header class="topbar" data-navbarbg="skin6">
            <nav class="navbar top-navbar navbar-expand-md navbar-light">
                <?php
                    include("logotipo.php");
                ?>
                 <!-- ============================================================== -->
                <!-- MENU SUPERIOR -->
                <!-- ============================================================== -->
                <?php
                    include("menu_superior.php");
                ?>
            </nav>
        </header>
        <aside class="left-sidebar" data-sidebarbg="skin5">
            <!-- ============================================================== -->
            <!-- MENU LATERAL -->
            <!-- ============================================================== -->
            <?php
                include("menu_lateral.php");
            ?>
        </aside>
        <div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-5 align-self-center">
                        <h4 class="page-title">Cadastro de Usuários</h4>
                    </div>
                    <div class="col-7 align-self-center">
                        <div class="d-flex align-items-center justify-content-end">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item">
                                        <a href="#">SGGP</a>
                                    </li>
                                    <li class="breadcrumb-item active" aria-current="page">Cadastrar Usuário</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container-fluid">
                <!-- ======================================== -->
                <!-- SCRIPT COM A VALIDAÇÃO DOS CAMPOS -->
                <!-- ======================================== -->
                <?php
                    include("valida_formCadUsuarios.php");
                ?>
                <div class="row">
                    <div class="col-12">
                        <div class="card card-body">
                            <h4 class="card-title">Líder de Pesquisa</h4>
                            <!-- <h5 class="card-subtitle"> FORMULÁRIO DE CADASTRO DE LIDERES </h5> -->
                            <form name="formCadUsuarios" method="post" action="gravando_usuario.php" enctype="multipart/form-data" class="form-horizontal m-t-30">
                                <div class="form-group">
                                    <label>Prontuário:</label>
                                    <input type="text" class="form-control" name="prontuario_lider">
                                </div>
                                <div class="form-group">
                                    <label>Nome:</label>
                                    <input type="text" class="form-control" name="nome_lider" >
                                </div>
                                <div class="form-group">
                                    <label >Email:</label>
                                    <input type="email" class="form-control" name="email_lider">
                                    <br/><input type="submit" onclick="return validar()" value="Gravar" id="gravar_lider" class="btn btn-secondary"/>
                                    
                                </div>
                        <!--        <div class="form-group">
                                    <label>Senha:</label>
                                    <input type="password" class="form-control" placeholder="">
                                </div>
                                <div class="form-group">
                                    <label>Text area</label>
                                    <textarea class="form-control" rows="5"></textarea>
                                </div>
                                <div class="form-group">
                                    <label>Read only input</label>
                                    <input class="form-control" type="text" placeholder="Readonly input here…" readonly>
                                </div>
                                <div class="form-group">
                                    <fieldset disabled>
                                        <label for="disabledTextInput">Disabled input</label>
                                        <input type="text" id="disabledTextInput" class="form-control" placeholder="Disabled input">
                                    </fieldset>
                                </div>
                                <div class="form-group row p-t-20">
                                    <div class="col-sm-4">
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input" id="customCheck1">
                                            <label class="custom-control-label" for="customCheck1">Check this custom checkbox</label>
                                        </div>
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input" id="customCheck2">
                                            <label class="custom-control-label" for="customCheck2">Check this custom checkbox</label>
                                        </div>
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input" id="customCheck3">
                                            <label class="custom-control-label" for="customCheck3">Check this custom checkbox</label>
                                        </div>
                                    </div>
                                    <div class="col-sm-4">
                                        <div class="custom-control custom-radio">
                                            <input type="radio" id="customRadio1" name="customRadio" class="custom-control-input">
                                            <label class="custom-control-label" for="customRadio1">Toggle this custom radio</label>
                                        </div>
                                        <div class="custom-control custom-radio">
                                            <input type="radio" id="customRadio2" name="customRadio" class="custom-control-input">
                                            <label class="custom-control-label" for="customRadio2">Toggle this custom radio</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>Input Select</label>
                                    <select class="custom-select col-12" id="inlineFormCustomSelect">
                                        <option selected>Choose...</option>
                                        <option value="1">One</option>
                                        <option value="2">Two</option>
                                        <option value="3">Three</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Default file upload</label>
                                    <input type="file" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label>Custom File upload</label>
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">Upload</span>
                                        </div>
                                        <div class="custom-file">
                                            <input type="file" class="custom-file-input" id="inputGroupFile01">
                                            <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>Helping text</label>
                                    <input type="text" class="form-control" placeholder="Helping text">
                                    <span class="help-block"><small>A block of help text that breaks onto a new line and may extend beyond one line.</small></span> </div>
                        -->
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <footer class="footer text-center">
                Todos os direitos reservados por SGGP. Desenvolvido por:
                <a href="">SGGP</a>.
            </footer>
        </div>
    </div>
    <?php
            include("scripts.php");
    ?>
</body>

</html>