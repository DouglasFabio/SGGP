 <?php
  $mysqli = mysqli_init();
 if (!$mysqli->real_connect('localhost', 'root', '', 'bd_sggp')) {
	die('Erro na conexão (' . mysqli_connect_errno() . ') '
	. mysqli_connect_error());
}

?>