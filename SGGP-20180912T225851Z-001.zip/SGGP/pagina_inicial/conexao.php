<?php
    //conexão com o banco de dados
    $con = mysql_connect("localhost","root","toor");
        mysql_select_db("bd_sggp");
        
        return $con;
?>