<!DOCTYPE html>
<html dir="pag" lang="en">
  <!-- ============================================================== -->
                <!--  HEAD -->
   <!-- ============================================================== -->
<?php
include("head.php");
?>

<body>
    <!-- ============================================================== -->
    <!-- Preloader - style you can find in spinners.css -->
    <!-- ============================================================== -->
    <div class="preloader">
        <div class="lds-ripple">
            <div class="lds-pos"></div>
            <div class="lds-pos"></div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- Main wrapper - style you can find in pages.scss -->
    <!-- ============================================================== -->
    <div id="main-wrapper" data-navbarbg="skin6" data-theme="light" data-layout="vertical" data-sidebartype="full" data-boxed-layout="full">
        <!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
        <header class="topbar" data-navbarbg="skin6">
            <nav class="navbar top-navbar navbar-expand-md navbar-light">
                <?php
                    include("logotipo.php");
                ?>
                 <!-- ============================================================== -->
                <!-- MENU SUPERIOR -->
                <!-- ============================================================== -->
                <?php
                    include("menu_superior.php");
                ?>
            </nav>
        </header>
        <aside class="left-sidebar" data-sidebarbg="skin5">
            <!-- ============================================================== -->
            <!-- MENU LATERAL -->
            <!-- ============================================================== -->
            <?php
                include("menu_lateral.php");
            ?>
        </aside>
        <div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-5 align-self-center">
                        <h4 class="page-title">Cadastro de Usuários</h4>
                    </div>
                    <div class="col-7 align-self-center">
                        <div class="d-flex align-items-center justify-content-end">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item">
                                        <a href="#">SGGP</a>
                                    </li>
                                    <li class="breadcrumb-item active" aria-current="page">Cadastrar Usuário</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container-fluid">
                <!-- ======================================== -->
                <!-- SCRIPT COM A VALIDAÇÃO DOS CAMPOS -->
                <!-- ======================================== -->
                <?php
                    include("valida_formCadUsuarios.php");
                
                    date_default_timezone_set('America/Sao_Paulo');
                    $data = date('Y-m-d H:i:s');
                                        
                    $prontuario = $_POST['prontuario_lider'];
                    $nome       = $_POST['nome_lider'];
                    $email      = $_POST['email_lider'];
                function geraSenha($tamanho = 8, $maiusculas = true, $numeros = true, $simbolos = true)
{
// Caracteres de cada tipo
$lmin = 'abcdefghijklmnopqrstuvwxyz';
$lmai = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
$num = '1234567890';
$simb = '!@#$%*-';
// Variáveis internas
$retorno = '';
$caracteres = '';
// Agrupamos todos os caracteres que poderão ser utilizados
$caracteres .= $lmin;
if ($maiusculas) $caracteres .= $lmai;
if ($numeros) $caracteres .= $num;
if ($simbolos) $caracteres .= $simb;
// Calculamos o total de caracteres possíveis
$len = strlen($caracteres);
for ($n = 1; $n <= $tamanho; $n++) {
// Criamos um número aleatório de 1 até $len para pegar um dos caracteres
$rand = mt_rand(1, $len);
// Concatenamos um dos caracteres na variável $retorno
$retorno .= $caracteres[$rand-1];
}
return $retorno;
}
                $palavra  = geraSenha();
//---------------------------------------------------------------------------------------------------------------

$Vai = "Sua senha: ".$palavra;

require_once("phpmailer/class.phpmailer.php");

define('GUSER', 'sggp.recovery@gmail.com');	// <-- Insira aqui o seu GMail
define('GPWD', 'sggp123456');		// <-- Insira aqui a senha do seu GMail

function smtpmailer($para, $de, $de_nome, $assunto, $corpo) { 
	global $error;
	$mail = new PHPMailer();
    $mail->IsHTML(true);
	$mail->IsSMTP();		// Ativar SMTP
	$mail->SMTPDebug = 0;		// Debugar: 1 = erros e mensagens, 2 = mensagens apenas
	$mail->SMTPAuth = true;		// Autenticação ativada
	$mail->SMTPSecure = 'tls';	// SSL REQUERIDO pelo GMail
	$mail->Host = 'smtp.gmail.com';	// SMTP utilizado
	$mail->Port = 587;  		// A porta 587 deverá estar aberta em seu servidor
	$mail->Username = GUSER;
	$mail->Password = GPWD;
	$mail->SetFrom($de, $de_nome);
	$mail->Subject = $assunto;
	$mail->Body = $corpo;
	$mail->AddAddress($para);
	if(!$mail->Send()) {
		$error = 'Mail error: '.$mail->ErrorInfo; 
		return false;
	} else {
		$error = 'Mensagem enviada!';
		return true;
	}
}


 if (smtpmailer($email , 'sggp.recovery@gmail.com', 'SGGP - Recovery', 'Recuperação de Senha', $Vai)) {


}
if (!empty($error)) echo $error;
//-----------------------------------------------------------------------------------------------------------------              
                
                    $comando_sql = "INSERT INTO `lideres` (`prontuario`, `nome`, `email`, `senha`, `data`) 
	                                VALUES ('$prontuario', '$nome', '$email', $palavra,'$data');";

	                $mysqli = mysqli_init();

	               if (! $mysqli) {
    	               die('A função mysqli_init falhou');
	               }
	               
                   include("conexao2.php");

                   if ($mysqli->query($comando_sql) === TRUE) {
                       echo "<div class=\"row\">
                    <div class=\"col-12\">
                        <div class=\"card card-body\">
                            <center><h4 class=\"card-title\">Cadastro realizado com sucesso!</h4></center>
                            <a href=\"cad_usuario.php\" id=\"cad_novo\" class=\"btn btn-secondary\">Cadastrar novamente</a>
                        </div>
                    </div>";
                   } else {
                        echo "Erro ao tentar salvar: " . $mysqli->error;
                   }
                    
                    
                    $mysqli->close();
                    
                ?>
                
            </div>
            <footer class="footer text-center">
                Todos os direitos reservados por SGGP. Desenvolvido por:
                <a href="">SGGP</a>.
            </footer>
        </div>
    </div>
    <?php
            include("scripts.php");
    ?>
</body>

</html>