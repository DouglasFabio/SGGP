<?php

error_reporting(0);
ini_set(“display_errors”, 0 );

?>

<?php
$conn = new mysqli("localhost", "root", "", "bd_sggp");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$senha = $_POST["senhaLoginLider"];
$prontuario = $_POST["prontuarioLoginLider"];

$sql = "SELECT `prontuario` ,`nome`, `email`, `verificaacesso_lider` FROM `lideres` WHERE `prontuario` = ".$prontuario." AND `senha` =".$senha;
$result = $conn->query($sql);

if ($result->num_rows > 0) {

      $resultado = $result->fetch_assoc();
      
      // Se a sessão não existir, inicia uma
      if (!isset($_SESSION)) session_start();
    
      // Salva os dados encontrados na sessão
      $_SESSION['UsuarioProntuario'] = $resultado['prontuario'];
      $_SESSION['UsuarioNome'] = $resultado['nome'];
      $_SESSION['UsuarioEmail'] = $resultado['email'];
    
    if($resultado["verificaacesso_lider"] == 0) {
        $query = "UPDATE lideres SET verificaacesso_lider = 1 WHERE prontuario = '$prontuario'";
        $conn->query($query);
        header('Location: ../admin/html/pag/index_lider1.php');
    }
    else{

         header('Location: ../admin/html/pag/index_lider.php');
    }
      
} else {
    header('Location: login_lider.php?erro=1');
    exit;
}

$conn->close();
//include("../admin/html/pag/conexao.php");
//
//    $prontuario = $_POST['prontuarioLoginLider'];
//
//$query = sprintf("SELECT verificaacesso_lider FROM lideres WHERE prontuario ='$prontuario'");
//// executa a query
//$dados = mysql_query($query, $con) or die(mysql_error());
//// transforma os dados em um array
//$linha = mysql_fetch_assoc($dados);
//// calcula quantos dados retornaram
//$total = mysql_num_rows($dados);
//
//// se o número de resultados for maior que zero, mostra os dados
//if($linha["verificaacesso_lider"] == 0) {
//    $query = sprintf("UPDATE lideres SET verificaacesso_lider = 1 WHERE prontuario = '$prontuario'");
//    $dados = mysql_query($query, $con) or die(mysql_error());
//    header('Location: ../admin/html/pag/index_lider.php');
//}
//else{
//    
//     header('Location: ../admin/html/pag/');
//}
//
//// tira o resultado da busca da memória
//mysql_free_result($dados);
?>
